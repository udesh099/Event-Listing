
<?php
	$p=$_GET['id'];
							$con1 = mysqli_connect("localhost","id9603976_users","users","id9603976_users");
							
                            $sqll="SELECT tag,image,description,title,id,location,date FROM users where id='$p'";
							$result=mysqli_query($con1,$sqll);
                            while($rows=mysqli_fetch_array($result)){
							$pp=$rows[0];
							$s=$rows[1];
							$s1=$rows[2];
							$s2=$rows[3];
							$s3=$rows[4];
							$s4=$rows[5];
							$s5=$rows[6];
							}
							?>

<!DOCTYPE HTML>
<html>
<head>
<title>Free Steam Website Template | Album :: w3layouts</title>
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link href="css/style.css" rel="stylesheet" type="text/css" media="all" />
<link href='//fonts.googleapis.com/css?family=Montserrat' rel='stylesheet' type='text/css'>
<link href='//fonts.googleapis.com/css?family=Dosis' rel='stylesheet' type='text/css'>
</head>
<body>
<div class="header-top">
	<div class="wrap">
        <div class="logo">
			<a href="index.php"><img src="images/logo.png" alt="" width="55%" height="55%"/></a>
		</div>
		<div class="cssmenu">
		  <nav id="nav" role="navigation">
			<a href="#nav" title="Show navigation">Show navigation</a>
			<a href="#" title="Hide navigation">Hide navigation</a>
			<ul class="clearfix">
				<li><a href="index.php">&nbsp&nbsp&nbsp&nbsp&nbspHome&nbsp&nbsp&nbsp&nbsp&nbsp</a></li>
				<li class="active"><a href="about.html"><span>&nbsp&nbsp&nbsp&nbsp&nbspAbout us&nbsp&nbsp&nbsp&nbsp&nbsp</span></a></li>
				<li><a href="work.html"><span>&nbsp&nbsp&nbsp&nbsp&nbspHow we Work&nbsp&nbsp&nbsp&nbsp&nbsp</span></a></li>
				<!-- <li><a href="pricing.html">Pricing</a></li>
				<li><a href="support.html">Support</a></li> -->
				<div class="clear"></div>
			</ul>
		    </nav>
		  </div>
		<!--  <div class="buttons">
				<div class="login_btn">
					<a href="login.html">Login / Signup</a>
				</div>
				<div class="get_btn">
					<a href="start.html">Get Listed Today</a>
				</div>
				<div class="clear"></div>
		   </div> -->
	     <div class="clear"></div>
		<h2 class="head">Find the <span class="m_1">next event </span>You'll want <span class="m_1">to attend</span></h2>
     </div>
    </div>
	
							

  <div class="main">
     <div class="wrap">
     	<h4 class="m_6"><?php echo $s2; ?></h4>
     	<p class="m_7"><?php echo $pp; ?></p>
		<?php echo"<img src='./images/$s' width='100%' height='100%'>"; ?>
     	
		<!-- <img src="images/album.jpg" alt=""/> -->
     	<div class="album-desc">
     	   <h3 class="m_8">Location</h3>
		   <p class="m_7"><?php echo $s4; ?></p>
     	   <span class="m_9">Event date:&nbsp&nbsp&nbsp&nbsp&nbsp<?php echo $s5; ?></span>
     	    
     	</div>
            <h4 class="m_6">Event Description</h4>
	     	<p class="m_11"><?php echo $s1; ?></p>
	     	</div>
     </div>
			
			<!--
			<div class="track">
	        <h4 class="m_6">Album Tracks</h4>
       		<ul class="songs">
				<li>
				   <div class="track-nr">1</div>
				   <div class="track-meta">
						<h5><a href="#">Nobody Move</a></h5>
						<p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat..</p>
				   </div>
				   <ul class="track-btns">
					  <li><a href="#" class="download-track">Download Track</a></li>
					  <li><a href="#" class="buy-track">Buy Track</a></li>
				  </ul>
			   </li>
			   <li>
				   <div class="track-nr">2</div>
				   <div class="track-meta">
						<h5><a href="#">Miss Kitten</a></h5>
						<p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat..</p>
				   </div>
			  </li>
			  <li>
				   <div class="track-nr">3</div>
				   <div class="track-meta">
						<h5><a href="#">Ignissim Congue</a></h5>
						<p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat..</p>
				   </div>
				   <ul class="track-btns">
						<li><a href="#" class="buy-track">Buy Track</a></li>
				   </ul>
			  </li>
			  <li>
				 <div class="track-nr">4</div>
                 <div class="track-meta">
			       <h5><a href="#">Risus et Justo</a></h5>
				   <p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat..</p>
				</div>
			  </li>
			  <li>
				 <div class="track-nr">5</div>
				 <div class="track-meta">
					<h5><a href="#">Mauris</a></h5>
					<p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat..</p>
				 </div>
				 <ul class="track-btns">
					<li><a href="#" class="download-track">Download Track</a></li>
				 </ul>
			  </li>
			  <li>
				 <div class="track-nr">6</div>
				 <div class="track-meta">
					<h5><a href="#">Pulvinar</a></h5>
					<p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat..</p>
				 </div>
				 <ul class="track-btns">
					<li><a href="#" class="buy-track">Buy Track</a></li>
				 </ul>
			 </li>
		</ul>
        </div> 
         <h4 class="m_6">Featured Albums</h4>
		   <div class="section group">
		   	   <div class="col_1_of_3 span_1_of_3">
				   <div class="container1 right">
						<img src="images/s14.jpg" alt="image">
						<article class="text css3-4">
							<h1><a href="#" class="css3-4">Thailand</a></h1>
						</article>
					</div>
				</div>
				 <div class="col_1_of_3 span_1_of_3">
				   <div class="container1 right">
						<img src="images/s15.jpg" alt="image">
						<article class="text css3-4">
							<h1><a href="#" class="css3-4">Thailand</a></h1>
						</article>
					</div>
				</div>
				 <div class="col_1_of_3 span_1_of_3">
				   <div class="container1 right">
						<img src="images/s16.jpg" alt="image">
						<article class="text css3-4">
							<h1><a href="#" class="css3-4">Thailand</a></h1>
						</article>
					</div>
				</div>
				<div class="clear"></div>	
			</div> -->
       
     <div class="footer">
     	<div class="wrap">
     	  <div class="footer-menu">
     		<ul>
				<li class="active"><a href="index.php">Home</a></li> 
				<li><a href="about.html">About us</a></li> 
				<li><a href="work.html">How we works</a></li> 
				<!-- <li><a href="industries.html">Industries</a></li> 
				<li><a href="features.html">Features</a></li>
				<li><a href="pricing.html">Pricing</a></li>
				<li><a href="faq.html">Faq's</a></li>
				<li><a href="features.html">Privacy policy</a></li>
				<li><a href="blog.html">Blog</a></li>
				<li><a href="work.html">Terms of service</a></li>
				<div class="clear"></div> -->
			</ul>
     	  </div>
     	  <div class="footer-bottom">
     	  	<div class="copy">
			   <p>© 2019 Steam. All rights reserved.</p>
		    </div>
		    <div class="social">	
			   <ul>	
				  <li class="facebook"><a href="#"><span> </span></a></li>
				  <li class="twitter"><a href="#"><span> </span></a></li>
				  <li class="linked"><a href="#"><span> </span></a></li>	
				 <!-- <li class="arrow"><a href="#"><span> </span></a></li>	
				  <li class="dot"><a href="#"><span> </span></a></li>
				  <li class="rss"><a href="#"><span> </span></a></li>	 -->	
			   </ul>
		    </div>
		    <div class="clear"></div>
     	  </div>
       </div>
     </div>
</body>
</html>
