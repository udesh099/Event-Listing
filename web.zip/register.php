<?php include('server.php') ?>
<?php 

  if (!isset($_SESSION['username'])) {
  	$_SESSION['msg'] = "You must log in first";
  	header('location: login.php');
  }
  if (isset($_GET['logout'])) {
  	session_destroy();
  	unset($_SESSION['username']);
  	header("location: login.php");
  }
?>



<!DOCTYPE HTML>
<html>
<head>
<title>Free Steam Website Template | Login :: w3layouts</title>
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link href="css/style.css" rel="stylesheet" type="text/css" media="all" />
<link href='//fonts.googleapis.com/css?family=Montserrat' rel='stylesheet' type='text/css'>
<link href='//fonts.googleapis.com/css?family=Dosis' rel='stylesheet' type='text/css'>
</head>
<body>
 <div class="header-top">
	<div class="wrap">
        <div class="logo">
			<a href="index.php"><img src="images/logo.png" alt="" width="55%" height="55%"/></a>
		</div>
		<div class="cssmenu">
		  <nav id="nav" role="navigation">
			<a href="#nav" title="Show navigation">Show navigation</a>
			<a href="#" title="Hide navigation">Hide navigation</a>
			<ul class="clearfix">
				<li><a href="index.php">&nbsp&nbsp&nbsp&nbsp&nbspHome&nbsp&nbsp&nbsp&nbsp&nbsp</a></li>
				<li class="active"><a href="about.html"><span>&nbsp&nbsp&nbsp&nbsp&nbspAbout us&nbsp&nbsp&nbsp&nbsp&nbsp</span></a></li>
				<li><a href="work.html"><span>&nbsp&nbsp&nbsp&nbsp&nbspHow we Work&nbsp&nbsp&nbsp&nbsp&nbsp</span></a></li>
				<!-- <li><a href="pricing.html">Pricing</a></li>
				<li><a href="support.html">Support</a></li> -->
				<div class="clear"></div> 
			</ul>
		    </nav>
		  </div>
		  <!--
		  <div class="buttons">
				<div class="login_btn">
					<a href="login.html">Login / Signup</a>
				</div>
				<div class="get_btn">
					<a href="start.html">Get Listed Today</a>
				</div>
				<div class="clear"></div>
		   </div>
		   -->
	     <div class="clear"></div>
		<h2 class="head">Find the <span class="m_1">next event </span>You'll want <span class="m_1">to attend</span></h2>
     </div>
    </div>
	<?php  if (isset($_SESSION['username'])) : ?>
    	<pre style="font-size:25px";><b>Welcome : </b><strong><?php echo $_SESSION['username']; ?></strong>                              <a href="login.php?logout='1'" style="color: red;float:right;"><b>logout</b></a> </pre>
    <?php endif ?>
  <div class="main">
     <div class="wrap">
      	 <div class="section group">
				<div class="cont span_2_of_blog">
				  <div class="login-title">
           		<h4 class="title">Event Addition</h4>
				<div id="loginbox" class="loginbox">
					<form action="server.php" method="post" name="login" id="login-form" enctype="multipart/form-data">
					  <fieldset class="input">
					    <p id="login-form-username">
					      <label for="modlgn_username">Title</label>
					      <input id="modlgn_username" type="text" name="title" class="inputbox" size="18" autocomplete="off">
					    </p>
					    <p id="login-form-password">
					      <label for="modlgn_passwd">Tag</label>
					      <input id="modlgn_passwd" type="text" name="tag" class="inputbox" size="18" autocomplete="off">
					    </p>
						<p id="login-form-username1">
					      <label for="modlgn_username1">Description</label><br>
					      <textarea id="modlgn_username1" name="description" class="inputbox" rows="18" cols="100" autocomplete="off"></textarea>
					    </p>
						<p id="login-form-username2">
					      <label for="modlgn_username2">Location</label>
					      <input id="modlgn_username2" type="text" name="location" class="inputbox" size="18" autocomplete="off">
					    </p>
						<p id="login-form-username3">
					      <label for="modlgn_username3">Date</label>
					      <input id="modlgn_username3" type="text" name="date" class="inputbox" size="18" autocomplete="off">
					    </p>
						<p id="login-form-username4">
					      <label for="modlgn_username4">Image</label>
					      <input id="modlgn_username4" type="file" name="file" id="file" >
					    </p>
					    
					    <input type="submit" name="register" class="button" value="Submit">
					  </fieldset>
					 </form>
				</div>
			</div>   
			</div>
		  <!--<div class="bsidebar span_1_of_blog">
					<h2 class="head4">Search</h2>
					<div class="search">
						<form>
							<input type="text" value="Search...." onfocus="this.value = '';" onblur="if (this.value == '') {this.value = 'Search';}">
							<input type="submit" value="">
						</form>
					</div> -->
					<!--
					<h2 class="head4">Categories</h2>
			        <ul class="list1">
					    <li><a href="#">consectetuer adipiscing elit</a></li>
			            <li><a href="#">Duis autem vel eum iriure dolo</a></li>
			            <li><a href="#">soluta nobis eleifend option</a></li>
			            <li><a href="#">consectetuer adipiscing elit</a></li>
			            <li><a href="#">Duis autem vel eum iriure dolo</a></li>
			            <li><a href="#">soluta nobis eleifend option</a></li>
		            </ul>	
	        <h2 class="head4">Tags</h2>
	        <ul class="tags">
				<li><a href="#">Events</a></li>
				<li><a href="#">Gallery</a></li>
				<li><a href="#">Videos</a></li>
				<li><a href="#">Albums</a></li>
				<li><a href="#">Solo Artists</a></li>
				<li><a href="#">Audio Post</a></li>
				<li><a href="#">Musical</a></li>
				<li><a href="#">Live</a></li>
				<li><a href="#">Concert</a></li>
			    <li><a href="#">Movie</a></li>
			 </ul>
			 -->
	     </div>
	   </div>
	   <div class="clear"></div>
	  </div>
   </div>
   <div class="footer">
      <div class="wrap">
     	  <div class="footer-menu">
     		<ul>
				<li class="active"><a href="index.php">Home</a></li> 
				<li><a href="about.html">About us</a></li> 
				<li><a href="work.html">How we works</a></li> 
				<!-- <li><a href="industries.html">Industries</a></li> 
				<li><a href="features.html">Features</a></li>
				<li><a href="pricing.html">Pricing</a></li>
				<li><a href="faq.html">Faq's</a></li>
				<li><a href="features.html">Privacy policy</a></li>
				<li><a href="blog.html">Blog</a></li>
				<li><a href="work.html">Terms of service</a></li>
				<div class="clear"></div> -->
			</ul>
     	  </div>
     	  <div class="footer-bottom">
     	  	<div class="copy">
			   <p>© 2019 . All rights reserved.</p>
		    </div>
		    <div class="social">	
			   <ul>	
				  <li class="facebook"><a href="#"><span> </span></a></li>
				  <li class="twitter"><a href="#"><span> </span></a></li>
				  <li class="linked"><a href="#"><span> </span></a></li>	
				 <!-- <li class="arrow"><a href="#"><span> </span></a></li>	
				  <li class="dot"><a href="#"><span> </span></a></li>
				  <li class="rss"><a href="#"><span> </span></a></li>	 -->	
			   </ul>
		    </div>
		    <div class="clear"></div>
     	  </div>
       </div>
   </div>
</body>
</html>