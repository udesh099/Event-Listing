<!DOCTYPE HTML>
<html>
<head>
<style>

ul{
	display:inline;
	padding:20px;
	
}
</style>
<title>IFMR</title>
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link href="css/style.css" rel="stylesheet" type="text/css" media="all" />
<link href='//fonts.googleapis.com/css?family=Montserrat' rel='stylesheet' type='text/css'>
<link href='//fonts.googleapis.com/css?family=Dosis' rel='stylesheet' type='text/css'>
<script type="text/javascript" src="js/jquery-v1.7.1.js"></script>
<script type="text/javascript" src="js/jquery-hover-effect.js"></script>
<script type="text/javascript">
//Image Hover
jQuery(document).ready(function(){
jQuery(function() {
	jQuery('ul.da-thumbs > li').hoverdir();
});
});
</script>
</head>
<body>
 <div class="header-top">
	<div class="wrap">
        <div class="logo">
			<a href="index.php"><img src="images/logo.png" alt="" width="55%" height="55%"/></a>
		</div>
		<div class="cssmenu">
		  <nav id="nav" role="navigation">
			<a href="#nav" title="Show navigation">Show navigation</a>
			<a href="#" title="Hide navigation">Hide navigation</a>
			
			<ul class="clearfix">
			
				<li><a href="index.php">&nbsp&nbsp&nbsp&nbsp&nbspHome&nbsp&nbsp&nbsp&nbsp&nbsp</a></li>
				<li class="active"><a href="about.html"><span>&nbsp&nbsp&nbsp&nbsp&nbspAbout us&nbsp&nbsp&nbsp&nbsp&nbsp</span></a></li>
				<li><a href="work.html"><span>&nbsp&nbsp&nbsp&nbsp&nbspHow we Work&nbsp&nbsp&nbsp&nbsp&nbsp</span></a></li>
			  <!--  <li><a href="pricing.html">Pricing</a></li>
				<li><a href="support.html">Support</a></li>  -->
				<div class="clear"></div>
			</ul>
			
		    </nav>
		  </div>
		<!--  <div class="buttons">
				<div class="login_btn">
					<a href="login.html">Login / Signup</a>
				</div>
				<div class="get_btn">
					<a href="start.html">Get Listed Today</a>
				</div>
				<div class="clear"></div>
		   </div> -->
	     <div class="clear"></div>
		<h2 class="head">Find the <span class="m_1">next event </span>You'll want <span class="m_1">to attend</span></h2>
     </div>
    </div>
	
  <div class="main">
        <div class="wrap">
        	<h4 class="m_6">Upcoming events</h4>
        	<div class="section group">
			<center>
			
				
						   
							
							<?php
							$con = mysqli_connect("localhost","id9603976_users","users","id9603976_users");
                            $sql='select id,title,tag,description,image from users';

                            if ($result=mysqli_query($con,$sql)){
                                
                                    // Fetch one and one row
                              
                                while ($row=mysqli_fetch_row($result)){
											$id=$row[0];
									
                                    
								echo "<div class='col_1_of_4 span_1_of_4'><div class='image_grid portfolio_4col'><ul class='portfolio_list da-thumbs'><li id='pz2'><img src='./images/$row[4]' alt='hello'><article class='da-animate da-slideFromLeft' style='display:inline;'/><h3>".$row[1]."</h3><span class='zoom'><a href='album.php?id=".$id."'></a></span></article></li></ul></div></div>";
									}
							   
							}
						?>
						    
			    		
				
	<div class="clear"></div>
       </div>
     </div>
	</div>
     <div class="footer">
     	<div class="wrap">
     	  <div class="footer-menu">
     		<ul>
				<li class="active"><a href="index.php">Home</a></li> 
				<li><a href="about.html">About us</a></li> 
				<li><a href="work.html">How we works</a></li> 
				<!-- <li><a href="industries.html">Industries</a></li> 
				<li><a href="features.html">Features</a></li>
				<li><a href="pricing.html">Pricing</a></li>
				<li><a href="faq.html">Faq's</a></li>
				<li><a href="features.html">Privacy policy</a></li>
				<li><a href="blog.html">Blog</a></li>
				<li><a href="work.html">Terms of service</a></li>-->
				<div class="clear"></div>
			</ul>
     	  </div>
     	  <div class="footer-bottom">
     	  	<div class="copy">
			   <p>© 2019. All rights reserved.</p>
		    </div>
		    <div class="social">	
			   <ul>	
				  <li class="facebook"><a href="#"><span> </span></a></li>
				  <li class="twitter"><a href="#"><span> </span></a></li>
				  <li class="linked"><a href="#"><span> </span></a></li>	
				<!--  <li class="arrow"><a href="#"><span> </span></a></li>	
				  <li class="dot"><a href="#"><span> </span></a></li>
				  <li class="rss"><a href="#"><span> </span></a></li>	-->	
			   </ul>
		    </div>
		    <div class="clear"></div>
     	  </div>
       </div>
     </div>
</body>
</html>
	
	
	
