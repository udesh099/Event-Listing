<?php
session_start();
$username="";
$password="";
$title="";
$s="";
$tag="";


$db = mysqli_connect('localhost', 'id9603976_users', 'users', 'id9603976_users');
if (isset($_POST['login'])) {
$username=$_POST['username'];
$password=$_POST['password'];
if (empty($username)) {
  	array_push($errors, "Username is required");
  }
  if (empty($password)) {
  	array_push($errors, "Password is required");
  }
  $query = "SELECT * FROM admin WHERE username='$username' AND password='$password'";
  $results = mysqli_query($db, $query);
  if (mysqli_num_rows($results) == 1) {
  $_SESSION['username'] = $username;
  $_SESSION['success'] = "You are now logged in";
  header('location: register.php');
  }
  else {
  		array_push($errors, "Wrong username/password combination ");
  	}

}


if (isset($_POST['register'])) {
$title=$_POST['title'];
$tag=$_POST['tag'];
$description=$_POST['description'];
$location=$_POST['location'];
$date=$_POST['date'];

if (empty($title)) {
  	echo("Title is required");
  }
  else if (empty($tag)) {
  	echo("Tag is required");
  }
  else if (empty($description)) {
  	echo("Description is required");
  }
  else if (empty($location)) {
  	echo("location is required");
  }
  else if (empty($date)) {
  	echo("date is required");
  }
$target_dir = "images/";
$s = basename($_FILES["file"]["name"]);
$target_file = $target_dir . basename($_FILES["file"]["name"]);
$uploadOk = 1;
$imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));
// Check if image file is a actual image or fake image
if(isset($_POST["submit"])) {
    $check = getimagesize($_FILES["file"]["tmp_name"]);
    if($check !== false) {
        echo "File is an image - " . $check["mime"] . ".";
        $uploadOk = 1;
    } else {
        echo "File is not an image.";
        $uploadOk = 0;
    }
}
// Check if file already exists
if (file_exists($target_file)) {
    echo "Sorry, file already exists.";
    $uploadOk = 0;
}
// Check file size
else if ($_FILES["file"]["size"] > 500000) {
    echo "Sorry, your file is too large.";
    $uploadOk = 0;
}
// Allow certain file formats
else if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg"
&& $imageFileType != "gif" ) {
    echo "Sorry, only JPG, JPEG, PNG & GIF files are allowed.";
    $uploadOk = 0;
}
// Check if $uploadOk is set to 0 by an error
else if ($uploadOk == 0) {
    echo "Sorry, your file was not uploaded.";
// if everything is ok, try to upload file
} else {
    if (move_uploaded_file($_FILES["file"]["tmp_name"], $target_file)) {
        echo "The file ". basename( $_FILES["file"]["name"]). " has been uploaded.";
    } else {
        echo "Sorry, there was an error uploading your file.";
    }
}



  	$q="INSERT into users(title,tag,description,location,date,image) VALUES('$title','$tag','$description','$location','$date','$s')";
	mysqli_query($db, $q);
	echo("The event".$title."has been successfully entered into the database");
    header('location: register.php');
    }





?>